import 'dart:convert';
import 'dart:core';


class Images {
  String? url;
  int? id;
  String? author;

  Images({required this.url, required this.id, required this.author});

  Images.fromJson(Map<String, dynamic> json) {
    Images(url: json['url'], id: json['id'], author: json['author']);
  }

  Map<String, dynamic> toJson()
   {
    final Map<String, dynamic> data = Map<String, dynamic> ();
  data['url'] = this.url;
  data['id'] = this.id;
  data['author']= this.author;

    return data;
    
  }







}
