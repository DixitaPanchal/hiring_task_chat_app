import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:interview/model.dart';

class GridScreen extends StatefulWidget {
  const GridScreen({super.key});

  @override
  State<GridScreen> createState() => _GridScreenState();
}

class _GridScreenState extends State<GridScreen> {
  List<Images> img = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
     fetchImages();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        title: Center(child: Text("Pugs")),
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //     fetchImages();
      //   },
      // ),
      body:
      ListView.builder(
          itemCount: img.length,
          itemBuilder: (context, index) {
            final images = img[index].url;
            return Container(
                child: Image.network(images!), );
          }),
    ));
  }

  //
  // Future<List> fetchImages() async {
  //   var client = http.Client();
  //   var uri = Uri.parse("https://picsum.photos/v2/list?page=1&limit=10");
  //   var response = client.get(uri);
  //
  //   if(response.statusCode == 200) {
  //     var json = await response.body;
  //   }

  Future<void> fetchImages() async {

    final uri = "https://picsum.photos/v2/list?page=1&limit=10";
    final url = Uri.parse(uri);
    http.Response response = await http.get(url);
    var json = await response.body;
    img = jsonDecode(json);
  }
}
